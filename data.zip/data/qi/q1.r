setwd("C:/Users/user/Downloads/data")
library(ggplot2)
library(gridExtra)
samples <- read.csv("qi/Customers.csv")
i <- 1
k <- 1
xclus <- c(5, 20, 100, 70, 120)
yclus <- c(5, 90, 10, 50, 100)

xcor <- samples$Annual_Income
ycor <- samples$Spending_Score

mean_distance <- c()

#iteration loop
while (k <= 100) {
  #cluster assignment
  i <- 1
  clus <- c()
  while (i <= 200) {
    distancediff <- c()
    for (j in 1: 5) {
      distance <- sqrt((xclus[j] - xcor[i])^2 + (yclus[j] - ycor[i])^2)
      distancediff <- append(distancediff, distance)
    }
    position <- match(min(distancediff), distancediff)
    clus <- append(clus, position)
    i <- i + 1
  }

  data <- data.frame(
    annual_income <- xcor,
    spending_score <- ycor,
    clusterindex <- clus
  )
  #cluster centroids update
  newx <- aggregate(data$annual_income,
                    list(data$clusterindex), FUN = mean)$x
  newy <- aggregate(data$spending_score,
                    list(data$clusterindex), FUN = mean)$x

  #print(newx)
  #print(newy)

  #mean distance Jcluster after update

  i <- 0
  distancesum <- c()
  while (i <= 200) {
    distance <- sqrt((newx[data$clusterindex....clus[i]]
                      - xcor[i])^2 + (newy[data$clusterindex....clus[i]]
                                      - ycor[i])^2)
    distancesum <- append(distancesum, distance)
    i <- i + 1
  }
  #print(sum(distancesum))
  avedis <- (sum(distancesum) / 200)
  mean_distance <- append(mean_distance, avedis)

  #check if need to stop
  consider <- newx == xclus
  consider <- append(consider, newy == yclus)
  #print(consider)
  if (all(consider)) {
    break
  }
  xclus <- newx
  yclus <- newy


  k <- k + 1
}
#print(data)
#print(mean_distance)

#plot 1

color <- c("1" = "red", "2" = "green",
           "3" = "blue", "4" = "purple", "5" = "brown")

p1 <- ggplot(data, aes(x = annual_income....xcor,
                       y = spending_score....ycor,
                       color = factor(clusterindex....clus))) +
  geom_point() +
  scale_color_manual(values = color) +
  labs(title = "K-means Clustering Scatter Plot",
       x = "Annual Income", y = "Spending Score",
       color = "Clusters")

#plot 2

meandis <- data.frame(dis = mean_distance, iterations = 1:k)

p2 <- ggplot(meandis, aes(x = iterations,
                          y = dis)) +
  geom_line() +
  labs(title = "Mean Distance and Training Iterations Plot",
       x = "Training Iterations", y = "Mean Distance")

plot(p1)
plot(p2)
grid.arrange(p1, p2, ncol = 2)