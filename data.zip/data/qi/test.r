x <- 0
y <- 3
print(x+y)