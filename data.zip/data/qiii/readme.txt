Please adjust the first line of the code which is setwd(..) for
changing directory to the "data" folder to run the code.

To see the plots and the labels clearly, please maximize the picture.