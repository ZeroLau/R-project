setwd("C:/Users/user/Downloads/data")

#part a

prices <- read.csv("qiii/house_prices_dataset.csv")

model_area <- lm(House_Price ~ House_Area, data = prices)
model_distance <- lm(House_Price ~ Distance_to_Center, data = prices)
model_age <- lm(House_Price ~ House_Age, data = prices)
model_condition <- lm(House_Price ~ House_Condition, data = prices)

par(mfrow = c(2, 2))

plot(prices$House_Area, prices$House_Price,
     main = "Regression for House Price and House Area",
     xlab = "House Area", ylab = "House Price")

abline(model_area, col = "red")
cfarea <- coefficients(model_area)
areafml <- paste0("House Price = ", round(cfarea[2], 1),
                  " * House Area + ", round(cfarea[1], 1))
text(150, predict(model_area, data.frame(House_Area = 150))
     + 23000, areafml, cex = 1.2, col = "red")



plot(prices$Distance_to_Center, prices$House_Price,
     main = "Regression for House Price and Distance to Center",
     xlab = "Distance to Center", ylab = "House Price")

abline(model_distance, col = "red")
cfdistance <- coefficients(model_distance)
distancefml <- paste0("House Price = ", round(cfdistance[2], 1),
                      " * Distance to Center + ", round(cfdistance[1], 1))
text(10, predict(model_distance, data.frame(Distance_to_Center = 10))
     + 15000, distancefml, cex = 1.2, col = "red")



plot(prices$House_Age, prices$House_Price,
     main = "Regression for House Price and House Age",
     xlab = "House Age", ylab = "House Price")

abline(model_age, col = "red")
cfage <- coefficients(model_age)
agefml <- paste0("House Price = ", round(cfage[2], 1),
                 " * House Age + ", round(cfage[1], 1))
text(25, predict(model_age, data.frame(House_Age = 25))
     + 15000, agefml, cex = 1.2, col = "red")



plot(prices$House_Condition, prices$House_Price,
     main = "Regression for House Price and House Condition",
     xlab = "House Condition", ylab = "House Price")

abline(model_condition, col = "red")
cfcondition <- coefficients(model_condition)
conditionfml <- paste0("House Price = ", round(cfcondition[2], 1),
                       " * House Condition + ", round(cfcondition[1], 1))
text(6, predict(model_condition, data.frame(House_Condition = 6))
     + 15000, conditionfml, cex = 1.2, col = "red")

#part b

model1 <- lm(House_Price ~ House_Area + Distance_to_Center, data = prices)
print(predict(model1, data.frame(House_Area = 250, Distance_to_Center = 5)))

#part c

model2 <- lm(House_Price ~ House_Area + House_Age, data = prices)
model3 <- lm(House_Price ~ House_Area + House_Condition, data = prices)
model4 <- lm(House_Price ~ House_Age + Distance_to_Center, data = prices)
model5 <- lm(House_Price ~ House_Condition + Distance_to_Center, data = prices)
model6 <- lm(House_Price ~ House_Age + House_Condition, data = prices)

r2 <- c(round(summary(model1)$r.squared, 4),
        round(summary(model2)$r.squared, 4),
        round(summary(model3)$r.squared, 4),
        round(summary(model4)$r.squared, 4),
        round(summary(model5)$r.squared, 4),
        round(summary(model6)$r.squared, 4))

bestmodel <- paste0("The R-squared values for all the models are ",
                    r2[1], ", ",
                    r2[2], ", ",
                    r2[3], ", ",
                    r2[4], ", ",
                    r2[5], ", ",
                    r2[6], ". So the best model is Model ",
                    match(max(r2), r2))

print(bestmodel)