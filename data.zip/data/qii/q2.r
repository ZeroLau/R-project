library(ggplot2)
set.seed(1234)
#part a
a <- rnorm(10000, 0.02, 0.05)
b <- exp(a)

data1 <- data.frame(value = b)

p <- ggplot(data1, aes(x = value, after_stat(density))) +
  geom_histogram(binwidth = 0.005) +
  labs(title = "log-normal distribution")

plot(p)

#part b

q <- ggplot(data1) +
  geom_histogram(binwidth = 0.008, aes(x = value, after_stat(density))) +
  stat_function(fun = dlnorm, args = list(meanlog = 0.02, sdlog = 0.05),
                colour = "red", lwd = 2) +
  labs(title = "log-normal distribution density plot")

plot(q)

#part c
print(mean(b))
print(var(b))

#part d
probability <- mean(b > 1.05)
print("Part d's probability is: ")
print(probability)

#part e

print("Part e's probability is: ")
print(plnorm(1.05, 0.02, 0.05, lower.tail = FALSE))